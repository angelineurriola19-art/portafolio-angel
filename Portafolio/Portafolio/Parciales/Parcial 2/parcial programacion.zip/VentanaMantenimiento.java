import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.*;

public class VentanaMantenimiento extends JFrame {

    private JTable tablaEquipos;
    private DefaultTableModel modelo;
    private JComboBox<String> comboEstado;

    public VentanaMantenimiento() {
        setTitle("Mantenimiento - Estados y Avance");
        setSize(900, 500);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);
        getContentPane().setBackground(new Color(240, 245, 255));
        setLayout(null);

        JLabel titulo = new JLabel("ESTADOS Y AVANCE DE MANTENIMIENTOS", SwingConstants.CENTER);
        titulo.setFont(new Font("Segoe UI", Font.BOLD, 18));
        titulo.setBounds(180, 10, 550, 30);
        add(titulo);

        String[] columnas = {"ID", "Equipo", "Marca", "Servicio", "Fecha Ingreso", "Fecha Salida", "Estado"};
        modelo = new DefaultTableModel(columnas, 0);
        tablaEquipos = new JTable(modelo);
        JScrollPane scroll = new JScrollPane(tablaEquipos);
        scroll.setBounds(40, 60, 800, 300);
        add(scroll);

        JLabel lblEstado = new JLabel("Cambiar estado:");
        lblEstado.setFont(new Font("Segoe UI", Font.BOLD, 13));
        lblEstado.setBounds(40, 380, 120, 25);
        add(lblEstado);

        comboEstado = new JComboBox<>(new String[]{"Pendiente", "En proceso", "Finalizado"});
        comboEstado.setBounds(160, 380, 150, 25);
        add(comboEstado);

        JButton btnActualizar = new JButton("Actualizar Estado");
        btnActualizar.setBounds(330, 380, 160, 30);
        btnActualizar.setBackground(new Color(100, 149, 237));
        btnActualizar.setForeground(Color.WHITE);
        btnActualizar.setFont(new Font("Segoe UI", Font.BOLD, 13));
        add(btnActualizar);

        JButton btnRefrescar = new JButton("Refrescar Lista");
        btnRefrescar.setBounds(510, 380, 150, 30);
        btnRefrescar.setBackground(new Color(60, 179, 113));
        btnRefrescar.setForeground(Color.WHITE);
        btnRefrescar.setFont(new Font("Segoe UI", Font.BOLD, 13));
        add(btnRefrescar);

        JButton btnCerrar = new JButton("Cerrar");
        btnCerrar.setBounds(680, 380, 120, 30);
        btnCerrar.setBackground(new Color(255, 99, 71));
        btnCerrar.setForeground(Color.WHITE);
        btnCerrar.setFont(new Font("Segoe UI", Font.BOLD, 13));
        add(btnCerrar);

        btnCerrar.addActionListener(e -> dispose());
        btnRefrescar.addActionListener(e -> cargarEquipos());
        btnActualizar.addActionListener(e -> actualizarEstado());

        cargarEquipos();
    }

    private void cargarEquipos() {
        modelo.setRowCount(0);
        try (Connection con = ConexionBD.obtenerConexion();
             Statement st = con.createStatement();
             ResultSet rs = st.executeQuery("SELECT id, equipo, marca, tipo_servicio, fecha_ingreso, fecha_salida, estado FROM equipos")) {

            while (rs.next()) {
                Object[] fila = {
                        rs.getInt("id"),
                        rs.getString("equipo"),
                        rs.getString("marca"),
                        rs.getString("tipo_servicio"),
                        rs.getString("fecha_ingreso"),
                        rs.getString("fecha_salida"),
                        rs.getString("estado")
                };
                modelo.addRow(fila);
            }

        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error al cargar datos: " + e.getMessage());
        }
    }

    private void actualizarEstado() {
        int fila = tablaEquipos.getSelectedRow();

        if (fila == -1) {
            JOptionPane.showMessageDialog(this, "Selecciona un registro primero.");
            return;
        }

        int id = (int) modelo.getValueAt(fila, 0);
        String nuevoEstado = (String) comboEstado.getSelectedItem();

        try (Connection con = ConexionBD.obtenerConexion();
             PreparedStatement ps = con.prepareStatement("UPDATE equipos SET estado = ? WHERE id = ?")) {

            ps.setString(1, nuevoEstado);
            ps.setInt(2, id);
            ps.executeUpdate();

            JOptionPane.showMessageDialog(this, "Estado actualizado correctamente.");
            cargarEquipos();

        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error al actualizar estado: " + e.getMessage());
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new VentanaMantenimiento().setVisible(true));
    }
}
