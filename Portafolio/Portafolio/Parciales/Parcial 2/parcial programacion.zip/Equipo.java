public class Equipo {
    private int id;
    private String numIngreso;
    private String fechaIngreso;
    private String equipo;
    private String marca;
    private String serie;
    private String tipoServicio;
    private String fechaSalida;   
    private double costoInicial;
    private double costoFinal;
    private String observacion;

    public Equipo() {}

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    public String getNumIngreso() { return numIngreso; }
    public void setNumIngreso(String numIngreso) { this.numIngreso = numIngreso; }
    public String getFechaIngreso() { return fechaIngreso; }
    public void setFechaIngreso(String fechaIngreso) { this.fechaIngreso = fechaIngreso; }
    public String getEquipo() { return equipo; }
    public void setEquipo(String equipo) { this.equipo = equipo; }
    public String getMarca() { return marca; }
    public void setMarca(String marca) { this.marca = marca; }
    public String getSerie() { return serie; }
    public void setSerie(String serie) { this.serie = serie; }
    public String getTipoServicio() { return tipoServicio; }
    public void setTipoServicio(String tipoServicio) { this.tipoServicio = tipoServicio; }
    public String getFechaSalida() { return fechaSalida; }
    public void setFechaSalida(String fechaSalida) { this.fechaSalida = fechaSalida; }
    public double getCostoInicial() { return costoInicial; }
    public void setCostoInicial(double costoInicial) { this.costoInicial = costoInicial; }
    public double getCostoFinal() { return costoFinal; }
    public void setCostoFinal(double costoFinal) { this.costoFinal = costoFinal; }
    public String getObservacion() { return observacion; }
    public void setObservacion(String observacion) { this.observacion = observacion; }
}
