import javax.swing.*;
import java.sql.*;
import java.util.Optional;

public class SentinelAuth {

    public static Optional<String> solicitarUsuarioInteractivo() {
        while (true) {
            String usuario = JOptionPane.showInputDialog(null, "Usuario:", "Acceso - Usuario", JOptionPane.QUESTION_MESSAGE);
            if (usuario == null) return Optional.empty();
            usuario = usuario.trim();
            if (usuario.isEmpty()) {
                JOptionPane.showMessageDialog(null, "El usuario no puede estar vacío.", "Error", JOptionPane.ERROR_MESSAGE);
                continue;
            }
            return Optional.of(usuario);
        }
    }

    public static Optional<char[]> solicitarClaveInteractiva() {
        while (true) {
            JPasswordField campoClave = new JPasswordField();
            int opcion = JOptionPane.showConfirmDialog(
                    null, campoClave, "Acceso - Contraseña",
                    JOptionPane.OK_CANCEL_OPTION, JOptionPane.QUESTION_MESSAGE);
            if (opcion != JOptionPane.OK_OPTION) return Optional.empty();
            char[] clave = campoClave.getPassword();
            if (clave == null || clave.length == 0) {
                JOptionPane.showMessageDialog(null, "La contraseña no puede estar vacía.", "Error", JOptionPane.ERROR_MESSAGE);
                continue;
            }
            return Optional.of(clave);
        }
    }

    public static boolean validarCredenciales(String usuario, char[] clave) {
        String sql = "SELECT 1 FROM usuarios WHERE nombre_usuario = ? AND clave = ?";
        try (Connection con = ConexionBD.obtenerConexion()) {
            if (con == null) {
                UiFaro.error("No hay conexión a la Base de Datos.\nRevisa driver/URL/credenciales en ConexionBD.java.");
                return false;
            }
            try (PreparedStatement ps = con.prepareStatement(sql)) {
                ps.setString(1, usuario);
                ps.setString(2, new String(clave));
                try (ResultSet rs = ps.executeQuery()) {
                    if (rs.next()) return true;
                    UiFaro.error("Usuario o contraseña incorrectos.");
                    return false;
                }
            }
        } catch (SQLException e) {
            UiFaro.error("Error al validar usuario: " + e.getMessage());
            return false;
        } catch (Exception e) {
            UiFaro.error("Error inesperado: " + e.getMessage());
            return false;
        }
    }
}
