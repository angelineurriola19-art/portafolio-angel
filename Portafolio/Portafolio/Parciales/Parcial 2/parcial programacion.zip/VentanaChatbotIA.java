import javax.swing.*;
import java.awt.*;

public class VentanaChatbotIA extends JFrame {

    private JTextArea areaChat;
    private JTextField txtMensaje;

    public VentanaChatbotIA() {
        setTitle("Chatbot Inteligente - Asistente NIBARRA");
        setSize(400, 600);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);

        setLayout(new BorderLayout());

        areaChat = new JTextArea();
        areaChat.setEditable(false);
        areaChat.setFont(new Font("Segoe UI", Font.PLAIN, 15));
        areaChat.setLineWrap(true);
        areaChat.setWrapStyleWord(true);
        areaChat.setBackground(new Color(245, 248, 250));

        JScrollPane scroll = new JScrollPane(areaChat);
        add(scroll, BorderLayout.CENTER);

        JPanel panelInferior = new JPanel(new BorderLayout());

        txtMensaje = new JTextField();
        txtMensaje.setFont(new Font("Segoe UI", Font.PLAIN, 15));

        JButton btnEnviar = new JButton("Enviar");
        btnEnviar.setBackground(new Color(37, 211, 102));
        btnEnviar.setForeground(Color.WHITE);
        btnEnviar.setFont(new Font("Segoe UI", Font.BOLD, 15));

        btnEnviar.addActionListener(e -> enviarMensaje());

        panelInferior.add(txtMensaje, BorderLayout.CENTER);
        panelInferior.add(btnEnviar, BorderLayout.EAST);

        add(panelInferior, BorderLayout.SOUTH);

        agregarBot("¡Hola! ¿En qué puedo ayudarte hoy?");
    }

    private void enviarMensaje() {
        String mensaje = txtMensaje.getText().trim();
        if (mensaje.isEmpty()) return;

        agregarUsuario(mensaje);
        txtMensaje.setText("");
        procesarBot(mensaje);
    }

    private void procesarBot(String mensaje) {
        mensaje = mensaje.toLowerCase();
        String respuesta;

        if (mensaje.contains("estado") || mensaje.contains("mantenimiento")) {
            respuesta = "Puedes cambiar los estados en el módulo Mantenimiento → Actualizar Estado.";
        } else if (mensaje.contains("servicio") || mensaje.contains("equipo")) {
            respuesta = "En Servicios puedes agregar, ver o eliminar equipos registrados.";
        } else if (mensaje.contains("hola") || mensaje.contains("buenas")) {
            respuesta = "¡Hola! ¿Cómo puedo ayudarte hoy?";
        } else if (mensaje.contains("ayuda")) {
            respuesta = "Claro. Puedes preguntarme sobre equipos, servicios o mantenimiento.";
        } else {
            respuesta = "No entendí muy bien, ¿podrías decirlo de otra forma?";
        }

        agregarBot(respuesta);
    }

    private void agregarUsuario(String texto) {
        areaChat.append(" Tú: " + texto + "\n\n");
    }

    private void agregarBot(String texto) {
        areaChat.append(" Bot: " + texto + "\n\n");
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new VentanaChatbotIA().setVisible(true));
    }
}
