import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

public class VentanaLogin extends JFrame {

    private JTextField campoUsuario;
    private JPasswordField campoClave;
    private JLabel etiquetaEstado;

    public VentanaLogin() {
        setTitle("Acceso al Sistema - NIBARRA");
        setSize(420, 280);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setResizable(false);
        getContentPane().setBackground(new Color(240, 248, 255));
        setLayout(null);

        JLabel titulo = new JLabel("INICIO DE SESIÓN", SwingConstants.CENTER);
        titulo.setFont(new Font("Segoe UI", Font.BOLD, 18));
        titulo.setBounds(90, 20, 240, 30);
        add(titulo);

        JLabel lblUsuario = new JLabel("Usuario:");
        lblUsuario.setBounds(60, 80, 100, 25);
        add(lblUsuario);

        campoUsuario = new JTextField();
        campoUsuario.setBounds(150, 80, 180, 25);
        add(campoUsuario);

        JLabel lblClave = new JLabel("Contraseña:");
        lblClave.setBounds(60, 120, 100, 25);
        add(lblClave);

        campoClave = new JPasswordField();
        campoClave.setBounds(150, 120, 180, 25);
        add(campoClave);

        JButton botonEntrar = new JButton("Entrar");
        botonEntrar.setBounds(90, 180, 100, 30);
        botonEntrar.setBackground(new Color(100, 149, 237));
        botonEntrar.setForeground(Color.WHITE);
        botonEntrar.setFocusPainted(false);
        botonEntrar.addActionListener(e -> validarCredenciales());
        add(botonEntrar);

        JButton botonSalir = new JButton("Salir");
        botonSalir.setBounds(230, 180, 100, 30);
        botonSalir.setBackground(new Color(220, 20, 60));
        botonSalir.setForeground(Color.WHITE);
        botonSalir.setFocusPainted(false);
        botonSalir.addActionListener(e -> System.exit(0));
        add(botonSalir);

        etiquetaEstado = new JLabel("", SwingConstants.CENTER);
        etiquetaEstado.setBounds(60, 150, 280, 20);
        etiquetaEstado.setForeground(Color.RED);
        add(etiquetaEstado);
    }

    private void validarCredenciales() {
        String usuario = campoUsuario.getText().trim();
        String clave = new String(campoClave.getPassword()).trim();

        if (usuario.isEmpty() || clave.isEmpty()) {
            etiquetaEstado.setText("Rellena todos los campos");
            return;
        }

        String sql = "SELECT * FROM usuarios WHERE nombre_usuario = ? AND clave = ?";

        try (Connection con = ConexionBD.obtenerConexion();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, usuario);
            ps.setString(2, clave);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                etiquetaEstado.setForeground(new Color(0, 128, 0));
                etiquetaEstado.setText("Inicio de sesión correcto");
                dispose(); 
                new VentanaPrincipal(usuario).setVisible(true); 
            } else {
                etiquetaEstado.setForeground(Color.RED);
                etiquetaEstado.setText("Usuario o contraseña incorrectos");
            }

        } catch (SQLException ex) {
            etiquetaEstado.setForeground(Color.RED);
            etiquetaEstado.setText("Error: " + ex.getMessage());
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new VentanaLogin().setVisible(true));
    }
}
