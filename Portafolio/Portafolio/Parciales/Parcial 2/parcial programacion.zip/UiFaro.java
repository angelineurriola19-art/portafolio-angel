import javax.swing.*;
import java.util.Optional;
import java.util.regex.Pattern;

public class UiFaro {

    private static final Pattern patronEntero = Pattern.compile("^[0-9]{1,9}$");

    public static void error(String msg) {
        JOptionPane.showMessageDialog(null, msg, "Error", JOptionPane.ERROR_MESSAGE);
    }

    public static void info(String msg) {
        JOptionPane.showMessageDialog(null, msg, "Información", JOptionPane.INFORMATION_MESSAGE);
    }

    public static boolean confirmar(String msg) {
        int r = JOptionPane.showConfirmDialog(null, msg, "Confirmación", JOptionPane.YES_NO_OPTION);
        return r == JOptionPane.YES_OPTION;
    }

    public static boolean confirmarSalida(String msg) {
        return confirmar(msg);
    }

    public static Optional<Integer> pedirNumero(String titulo, String mensaje, int min, int max) {
        while (true) {
            String input = JOptionPane.showInputDialog(null, mensaje, titulo, JOptionPane.QUESTION_MESSAGE);
            if (input == null) return Optional.empty();
            input = input.trim();
            if (!patronEntero.matcher(input).matches()) {
                error("Solo se admiten números enteros.");
                continue;
            }
            int num = Integer.parseInt(input);
            if (num < min || num > max) {
                error("Debe estar entre " + min + " y " + max + ".");
                continue;
            }
            return Optional.of(num);
        }
    }
}
