import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import java.util.*;
import com.toedter.calendar.JCalendar;

public class VentanaCalendario extends JFrame {

    private JCalendar calendario;
    private JTextArea txtEventos;
    private Map<String, java.util.List<String>> mantenimientosPorFecha = new HashMap<>();

    public VentanaCalendario() {
        setTitle("Calendario de Mantenimientos - NIBARRA");
        setSize(850, 550);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(null);

        getContentPane().setBackground(new Color(245, 248, 255));

        JPanel panel = new JPanel();
        panel.setBackground(Color.WHITE);
        panel.setLayout(null);
        panel.setBounds(25, 25, 780, 460);
        panel.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(180, 200, 255), 2, true),
                BorderFactory.createEmptyBorder(10, 10, 10, 10)
        ));
        add(panel);

        JLabel titulo = new JLabel("Calendario de Mantenimientos", SwingConstants.CENTER);
        titulo.setFont(new Font("Segoe UI", Font.BOLD, 20));
        titulo.setBounds(180, 10, 420, 30);
        titulo.setForeground(new Color(50, 70, 150));
        panel.add(titulo);

        calendario = new JCalendar();
        calendario.setBounds(40, 60, 360, 300);
        calendario.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        calendario.setBackground(new Color(240, 245, 255));
        panel.add(calendario);

        JPanel panelEventos = new JPanel();
        panelEventos.setBackground(new Color(248, 250, 255));
        panelEventos.setLayout(null);
        panelEventos.setBounds(420, 60, 320, 300);
        panelEventos.setBorder(BorderFactory.createTitledBorder(
                BorderFactory.createLineBorder(new Color(180, 200, 255)),
                "Mantenimientos del día seleccionado",
                0, 0, new Font("Segoe UI", Font.BOLD, 13), new Color(50, 70, 150)
        ));
        panel.add(panelEventos);

        txtEventos = new JTextArea();
        txtEventos.setEditable(false);
        txtEventos.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        txtEventos.setBackground(new Color(250, 252, 255));
        txtEventos.setForeground(new Color(60, 60, 80));
        JScrollPane scroll = new JScrollPane(txtEventos);
        scroll.setBounds(15, 25, 285, 230);
        scroll.setBorder(BorderFactory.createLineBorder(new Color(200, 210, 240)));
        panelEventos.add(scroll);

        JButton btnRefrescar = crearBoton("Actualizar Lista", new Color(100, 149, 237), 40, 390);
        JButton btnCerrar = crearBoton("Cerrar", new Color(255, 99, 71), 620, 390);
        panel.add(btnRefrescar);
        panel.add(btnCerrar);

        btnCerrar.addActionListener(e -> dispose());
        btnRefrescar.addActionListener(e -> cargarMantenimientos());
        calendario.addPropertyChangeListener("calendar", evt -> mostrarEventosDelDia());

        cargarMantenimientos();
    }

    private JButton crearBoton(String texto, Color color, int x, int y) {
        JButton boton = new JButton(texto);
        boton.setBounds(x, y, 180, 40);
        boton.setBackground(color);
        boton.setForeground(Color.WHITE);
        boton.setFont(new Font("Segoe UI", Font.BOLD, 14));
        boton.setFocusPainted(false);
        boton.setBorder(BorderFactory.createEmptyBorder());
        boton.setCursor(new Cursor(Cursor.HAND_CURSOR));

        boton.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent e) {
                boton.setBackground(color.darker());
            }

            public void mouseExited(MouseEvent e) {
                boton.setBackground(color);
            }
        });
        return boton;
    }

    private void cargarMantenimientos() {
        mantenimientosPorFecha.clear();

        try (Connection con = ConexionBD.obtenerConexion();
             Statement st = con.createStatement();
             ResultSet rs = st.executeQuery("SELECT equipo, tipo_servicio, fecha_ingreso, fecha_salida FROM equipos")) {

            while (rs.next()) {
                String equipo = rs.getString("equipo");
                String tipo = rs.getString("tipo_servicio");
                String fecha = rs.getString("fecha_salida");

                if (fecha == null || fecha.trim().isEmpty()) continue;

                mantenimientosPorFecha
                        .computeIfAbsent(fecha, k -> new ArrayList<>())
                        .add( equipo + " — " + tipo);
            }

        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error cargando mantenimientos: " + e.getMessage());
        }

        mostrarEventosDelDia();
    }

    private void mostrarEventosDelDia() {
        Calendar fechaSeleccionada = calendario.getCalendar();
        int año = fechaSeleccionada.get(Calendar.YEAR);
        int mes = fechaSeleccionada.get(Calendar.MONTH) + 1;
        int dia = fechaSeleccionada.get(Calendar.DAY_OF_MONTH);

        String fechaStr = String.format("%04d-%02d-%02d", año, mes, dia);

        txtEventos.setText("");

        if (mantenimientosPorFecha.containsKey(fechaStr)) {
            txtEventos.append("Fecha: " + fechaStr + "\n\n");
            for (String item : mantenimientosPorFecha.get(fechaStr)) {
                txtEventos.append(item + "\n");
            }
        } else {
            txtEventos.append("No hay mantenimientos programados para esta fecha.");
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new VentanaCalendario().setVisible(true));
    }
}
