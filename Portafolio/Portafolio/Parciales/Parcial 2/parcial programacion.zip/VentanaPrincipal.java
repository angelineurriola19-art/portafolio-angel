import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class VentanaPrincipal extends JFrame {

    private final String usuarioActivo;

    public VentanaPrincipal(String usuario) {
        this.usuarioActivo = usuario;

        setTitle("SISTEMA DE MANTENIMIENTO - NIBARRA");
        setSize(760, 430);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setResizable(false);

        JPanel panel = new JPanel(null);
        panel.setBackground(new Color(240, 245, 255));
        add(panel);

        JLabel titulo = new JLabel("SISTEMA DE MANTENIMIENTO NIBARRA", SwingConstants.CENTER);
        titulo.setFont(new Font("Segoe UI", Font.BOLD, 20));
        titulo.setBounds(80, 20, 600, 30);
        panel.add(titulo);

        JLabel usuarioLbl = new JLabel("Sesión iniciada como: " + usuarioActivo, SwingConstants.CENTER);
        usuarioLbl.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        usuarioLbl.setBounds(80, 50, 600, 20);
        panel.add(usuarioLbl);

        JButton btnServicios     = crearBoton("Servicios (CRUD de Equipos)", 90, 110);
        JButton btnCalendario    = crearBoton("Calendario de Mantenimientos", 90, 160);
        JButton btnMantenimiento = crearBoton("Mantenimiento (Estados y Avance)", 90, 210);
        JButton btnChatbot       = crearBoton("ChatBot Inteligente", 90, 260);
        JButton btnSalir         = crearBoton("Cerrar Sesión", 90, 310);
        btnSalir.setBackground(new Color(255, 99, 71));

        btnServicios.addActionListener(e -> new VentanaServicios().setVisible(true));
        btnCalendario.addActionListener(e -> new VentanaCalendario().setVisible(true));
        btnMantenimiento.addActionListener(e -> new VentanaMantenimiento().setVisible(true));
        btnChatbot.addActionListener(e -> new VentanaChatbotIA().setVisible(true));

        btnSalir.addActionListener(e -> {
            dispose();
            new VentanaLogin().setVisible(true);
        });

        panel.add(btnServicios);
        panel.add(btnCalendario);
        panel.add(btnMantenimiento);
        panel.add(btnChatbot);
        panel.add(btnSalir);
    }

    private JButton crearBoton(String texto, int x, int y) {
        JButton b = new JButton(texto);
        b.setBounds(x, y, 580, 36);
        b.setFont(new Font("Segoe UI", Font.BOLD, 14));
        b.setBackground(new Color(100,149,237));
        b.setForeground(Color.WHITE);
        b.setFocusPainted(false);
        b.setBorder(BorderFactory.createEmptyBorder());
        b.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent e){ b.setBackground(new Color(65,105,225)); }
            public void mouseExited (MouseEvent e){ b.setBackground(new Color(100,149,237)); }
        });
        return b;
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new VentanaPrincipal("UsuarioDemo").setVisible(true));
    }
}
