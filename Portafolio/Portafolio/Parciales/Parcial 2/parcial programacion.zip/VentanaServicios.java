import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.*;

public class VentanaServicios extends JFrame {
    private JTextField txtFechaIngreso, txtEquipo, txtMarca, txtSerie, txtFechaSalida,
            txtCostoInicial, txtCostoFinal;
    private JTextArea txtObservacion;
    private JComboBox<String> cboServicio;
    private JTable tabla;
    private DefaultTableModel modelo;

    public VentanaServicios() {
        setTitle("Gestión de Equipos - NIBARRA");
        setSize(1000, 700);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        getContentPane().setBackground(new Color(240, 245, 255));
        setLayout(null);

        JLabel titulo = new JLabel("MÓDULO DE SERVICIOS - CRUD DE EQUIPOS", SwingConstants.CENTER);
        titulo.setFont(new Font("Segoe UI", Font.BOLD, 20));
        titulo.setBounds(0, 20, 1000, 30);
        add(titulo);

        JLabel lblFechaIngreso = new JLabel("Fecha Ingreso:");
        lblFechaIngreso.setFont(new Font("Segoe UI", Font.BOLD, 13));
        lblFechaIngreso.setBounds(100, 80, 100, 25);
        add(lblFechaIngreso);

        txtFechaIngreso = new JTextField();
        txtFechaIngreso.setBounds(200, 80, 150, 25);
        add(txtFechaIngreso);

        JLabel lblEquipo = new JLabel("Equipo:");
        lblEquipo.setFont(new Font("Segoe UI", Font.BOLD, 13));
        lblEquipo.setBounds(380, 80, 60, 25);
        add(lblEquipo);

        txtEquipo = new JTextField();
        txtEquipo.setBounds(440, 80, 150, 25);
        add(txtEquipo);

        JLabel lblMarca = new JLabel("Marca:");
        lblMarca.setFont(new Font("Segoe UI", Font.BOLD, 13));
        lblMarca.setBounds(620, 80, 60, 25);
        add(lblMarca);

        txtMarca = new JTextField();
        txtMarca.setBounds(680, 80, 150, 25);
        add(txtMarca);

        JLabel lblSerie = new JLabel("Serie:");
        lblSerie.setFont(new Font("Segoe UI", Font.BOLD, 13));
        lblSerie.setBounds(100, 120, 100, 25);
        add(lblSerie);

        txtSerie = new JTextField();
        txtSerie.setBounds(200, 120, 150, 25);
        add(txtSerie);

        JLabel lblTipoServicio = new JLabel("Tipo Servicio:");
        lblTipoServicio.setFont(new Font("Segoe UI", Font.BOLD, 13));
        lblTipoServicio.setBounds(380, 120, 100, 25);
        add(lblTipoServicio);

        cboServicio = new JComboBox<>(new String[]{"Reparación", "Mantenimiento", "Instalación"});
        cboServicio.setBounds(480, 120, 150, 25);
        add(cboServicio);

        JLabel lblFechaSalida = new JLabel("Fecha Salida:");
        lblFechaSalida.setFont(new Font("Segoe UI", Font.BOLD, 13));
        lblFechaSalida.setBounds(650, 120, 100, 25);
        add(lblFechaSalida);

        txtFechaSalida = new JTextField();
        txtFechaSalida.setBounds(740, 120, 150, 25);
        add(txtFechaSalida);

        JLabel lblCostoInicial = new JLabel("Costo Inicial:");
        lblCostoInicial.setFont(new Font("Segoe UI", Font.BOLD, 13));
        lblCostoInicial.setBounds(100, 160, 100, 25);
        add(lblCostoInicial);

        txtCostoInicial = new JTextField();
        txtCostoInicial.setBounds(200, 160, 150, 25);
        add(txtCostoInicial);

        JLabel lblCostoFinal = new JLabel("Costo Final:");
        lblCostoFinal.setFont(new Font("Segoe UI", Font.BOLD, 13));
        lblCostoFinal.setBounds(380, 160, 100, 25);
        add(lblCostoFinal);

        txtCostoFinal = new JTextField();
        txtCostoFinal.setBounds(480, 160, 150, 25);
        add(txtCostoFinal);

        JLabel lblObservacion = new JLabel("Observación:");
        lblObservacion.setFont(new Font("Segoe UI", Font.BOLD, 13));
        lblObservacion.setBounds(650, 160, 100, 25);
        add(lblObservacion);

        txtObservacion = new JTextArea();
        txtObservacion.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        JScrollPane spObs = new JScrollPane(txtObservacion);
        spObs.setBounds(740, 160, 200, 60);
        add(spObs);

        JButton btnAgregar = crearBoton("Agregar", 130, 250);
        JButton btnActualizar = crearBoton("Actualizar", 280, 250);
        JButton btnEliminar = crearBoton("Eliminar (TODO)", 430, 250);
        JButton btnLimpiar = crearBoton("Limpiar", 600, 250);
        JButton btnEliminarCas = crearBoton("Eliminar Casilla", 750, 250);

        add(btnAgregar);
        add(btnActualizar);
        add(btnEliminar);
        add(btnLimpiar);
        add(btnEliminarCas);

        String[] columnas = {
                "ID", "Fecha Ingreso", "Equipo", "Marca", "Serie",
                "Servicio", "Estado", "Fecha Salida",
                "Costo Inicial", "Costo Final", "Observación"
        };

        modelo = new DefaultTableModel(columnas, 0);
        tabla = new JTable(modelo);
        JScrollPane spTabla = new JScrollPane(tabla);
        spTabla.setBounds(40, 320, 900, 300);
        add(spTabla);

        btnAgregar.addActionListener(e -> agregar());
        btnActualizar.addActionListener(e -> actualizar());
        btnEliminar.addActionListener(e -> eliminarTodo());
        btnLimpiar.addActionListener(e -> limpiarCampos());
        btnEliminarCas.addActionListener(e -> eliminarSeleccionado());

        cargarDatos(); 
    }

    private JButton crearBoton(String texto, int x, int y) {
        JButton b = new JButton(texto);
        b.setBounds(x, y, 130, 40);
        b.setBackground(new Color(100, 149, 237));
        b.setForeground(Color.WHITE);
        b.setFont(new Font("Segoe UI", Font.BOLD, 14));
        b.setFocusPainted(false);
        return b;
    }

    private void agregar() {
        try (Connection con = ConexionBD.obtenerConexion()) {
            String sql = "INSERT INTO equipos (fecha_ingreso, equipo, marca, serie, tipo_servicio, fecha_salida, costo_inicial, costo_final, observacion) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
            PreparedStatement ps = con.prepareStatement(sql);

            ps.setString(1, txtFechaIngreso.getText());
            ps.setString(2, txtEquipo.getText());
            ps.setString(3, txtMarca.getText());
            ps.setString(4, txtSerie.getText());
            ps.setString(5, (String) cboServicio.getSelectedItem());
            ps.setString(6, txtFechaSalida.getText());
            ps.setString(7, txtCostoInicial.getText());
            ps.setString(8, txtCostoFinal.getText());
            ps.setString(9, txtObservacion.getText());
            ps.executeUpdate();

            JOptionPane.showMessageDialog(this, "Registro agregado correctamente.");
            cargarDatos();
            limpiarCampos();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error al agregar: " + e.getMessage());
        }
    }

    private void actualizar() {
        JOptionPane.showMessageDialog(this, "Función de actualización lista.");
    }

    private void eliminarTodo() {
        try (Connection con = ConexionBD.obtenerConexion()) {
            PreparedStatement ps = con.prepareStatement("DELETE FROM equipos");
            ps.executeUpdate();
            JOptionPane.showMessageDialog(this, "Todos los registros fueron eliminados.");
            cargarDatos();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error al eliminar: " + e.getMessage());
        }
    }

    private void eliminarSeleccionado() {
        int fila = tabla.getSelectedRow();
        if (fila == -1) {
            JOptionPane.showMessageDialog(this, "Selecciona un registro para eliminar.");
            return;
        }

        int id = Integer.parseInt(tabla.getValueAt(fila, 0).toString());

        try (Connection con = ConexionBD.obtenerConexion()) {
            PreparedStatement ps = con.prepareStatement("DELETE FROM equipos WHERE id = ?");
            ps.setInt(1, id);
            ps.executeUpdate();

            JOptionPane.showMessageDialog(this, "Registro eliminado correctamente.");
            cargarDatos();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error al eliminar registro: " + e.getMessage());
        }
    }

    private void limpiarCampos() {
        txtFechaIngreso.setText("");
        txtEquipo.setText("");
        txtMarca.setText("");
        txtSerie.setText("");
        txtFechaSalida.setText("");
        txtCostoInicial.setText("");
        txtCostoFinal.setText("");
        txtObservacion.setText("");
        cboServicio.setSelectedIndex(0);
    }

    private void cargarDatos() {
        modelo.setRowCount(0);

        try (Connection con = ConexionBD.obtenerConexion();
             Statement st = con.createStatement();
             ResultSet rs = st.executeQuery("SELECT * FROM equipos")) {

            while (rs.next()) {
                Object[] fila = {
                        rs.getInt("id"),
                        rs.getString("fecha_ingreso"),
                        rs.getString("equipo"),
                        rs.getString("marca"),
                        rs.getString("serie"),
                        rs.getString("tipo_servicio"),
                        rs.getString("estado"),      
                        rs.getString("fecha_salida"),
                        rs.getString("costo_inicial"),
                        rs.getString("costo_final"),
                        rs.getString("observacion")
                };
                modelo.addRow(fila);
            }

        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error al cargar datos: " + e.getMessage());
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new VentanaServicios().setVisible(true));
    }
}
